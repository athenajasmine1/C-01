﻿using ModernAppliances.Entities;
using ModernAppliances.Entities.Abstract;
using ModernAppliances.Helpers;
using System.Runtime.CompilerServices;

namespace ModernAppliances
{
    /// <summary>
    /// Manager class for Modern Appliances
    /// </summary>
    /// <remarks>Author: Mark Badillo </remarks>
    /// <remarks>Date: 09/20/23 </remarks>
    internal class MyModernAppliances : ModernAppliances
    {
        /// <summary>
        /// Option 1: Performs a checkout
        /// </summary>
        public override void Checkout()
        {
            // Write "Enter the item number of an appliance: "
            Console.WriteLine("Enter the item number of an appliance: ");
            // Create long variable to hold item number
            long itemNum = 0;

            // Get user input as string and assign to variable.
            string input = Console.ReadLine();
            // Convert user input from string to long and store as item number variable.
            long itemNum1 = long.Parse(input);

            // Create 'foundAppliance' variable to hold appliance with item number
            // Assign null to foundAppliance (foundAppliance may need to be set as nullable)
            Appliance? found = null;


            // Loop through Appliances
            // Test appliance item number equals entered item number
            // Assign appliance in list to foundAppliance variable
            // Break out of loop (since we found what need to)
            foreach (Appliance appliance in Appliances)
            {
                if (appliance.ItemNumber == itemNum1)
                {
                    found = appliance;
                    break;
                }
            }


            // Test appliance was not found (foundAppliance is null)
            // Write "No appliances found with that item number."
            if (found == null)
            {
                Console.WriteLine("No appliances found with the item number.");
            }
            // Otherwise (appliance was found)
            // Test found appliance is available
            // Checkout found appliance
            else
            {
                if (found.IsAvailable)
                {
                    Console.WriteLine("Appliance" + " " + found.ItemNumber + " " + "has been checked out.");
                }
                else
                {
                    Console.WriteLine("The appliance is not available to be checked out.");

                }
            }
            // Write "Appliance has been checked out."
            // Otherwise (appliance isn't available)
            // Write "The appliance is not available to be checked out."
        }

        /// <summary>
        /// Option 2: Finds appliances
        /// </summary>
        public override void Find()
        {
            // Write "Enter brand to search for:"
            Console.WriteLine("Enter brand to search for: ");
            // Create string variable to hold entered brand
            // Get user input as string and assign to variable.
            string brand = Console.ReadLine();
            // Create list to hold found Appliance objects
            List<Appliance> found = new List<Appliance>();
            // Iterate through loaded appliances
            // Test current appliance brand matches what user entered
            // Add current appliance in list to found list
            foreach (Appliance appliance in Appliances)
            {
                if (brand == appliance.Brand)
                {
                    found.Add(appliance);
                }
                // Display found appliances
                // DisplayAppliancesFromList(found, 0);
            }
            DisplayAppliancesFromList(found, 0);
        }

        /// <summary>
        /// Displays Refridgerators
        /// </summary>
        public override void DisplayRefrigerators()
        {
            // Write "Possible options:"

            // Write "0 - Any"
            // Write "2 - Double doors"
            // Write "3 - Three doors"
            // Write "4 - Four doors"
            Console.WriteLine("Possible opions: ");
            Console.WriteLine("0 - Any");
            Console.WriteLine("2 - Double doors");
            Console.WriteLine("3 - Three doors");
            Console.WriteLine("4 - Four doors");
            Console.WriteLine("Enter number of doors: ");

            // Write "Enter number of doors: "

            // Create variable to hold entered number of doors
            long doorNum = 0;
            // Get user input as string and assign to variable
            string input = Console.ReadLine();
            // Convert user input from string to int and store as number of doors variable.
            int doorNum1 = Convert.ToInt32(input);
            // Create list to hold found Appliance objects
            List<Appliance> found = new List<Appliance>();

            foreach (Appliance appliance in Appliances)
            {
                if (appliance is Refrigerator)
                {
                    Refrigerator refrigerator = (Refrigerator)appliance;
                    if (doorNum1 == 0 || refrigerator.Doors == doorNum1)
                    {
                        found.Add(appliance);
                    }
                    // Iterate/loop through Appliances
                    // Test that current appliance is a refrigerator
                    // Down cast Appliance to Refrigerator
                    // Refrigerator refrigerator = (Refrigerator) appliance;

                    // Test user entered 0 or refrigerator doors equals what user entered.
                    // Add current appliance in list to found list


                }
            }
            DisplayAppliancesFromList(found, 0);
            // Display found appliances
            // DisplayAppliancesFromList(found, 0);
        }

        /// <summary>
        /// Displays Vacuums
        /// </summary>
        /// <param name="grade">Grade of vacuum to find (or null for any grade)</param>
        /// <param name="voltage">Vacuum voltage (or 0 for any voltage)</param>
        public override void DisplayVacuums()
        {
            // Write "Possible options:"
            Console.WriteLine("Possible options: ");
            Console.WriteLine("0 - Any");
            Console.WriteLine("1 - Residential");
            Console.WriteLine("2 - Commercial");
            Console.WriteLine("Enter grade: ");

            // Write "0 - Any"
            // Write "1 - Residential"
            // Write "2 - Commercial"

            // Write "Enter grade:"
            string input = Console.ReadLine();
            // Get user input as string and assign to variable
            string grade = "";
            // Create grade variable to hold grade to find (Any, Residential, or Commercial)
            if (input == "0")
            {
                // Assign "Any" to grade
                grade = "Any";
            }
            // Test input is "1"
            else if (input == "1")
            {
                // Assign "Residential" to grade
                grade = "Residential";
            }
            // Test input is "2"
            else if (input == "2")
            {
                // Assign "Commercial" to grade
                grade = "Commercial";
            }
            // Otherwise (input is something else)
            else
            {
                // Write "Invalid option."
                Console.WriteLine("Invalid Option.");
                return;
            }


            // Return to calling (previous) method
            // return;

            // Write "Possible options:"
            Console.WriteLine("Possible options: ");

            // Write "0 - Any"
            Console.WriteLine("0 - Any");

            // Write "1 - 18 Volt"
            Console.WriteLine("1 - 18 Volt");

            // Write "2 - 24 Volt"
            Console.WriteLine("2- 24 Volt");

            // Write "Enter voltage:"
            Console.WriteLine("Enter battery voltage value:  ");

            // Get user input as string
            string input1 = Console.ReadLine();
            // Create variable to hold voltage
            short voltage = 0;
            // Test input is "0"
            if (input1 == "0")
            {
                // Assign 0 to voltage
                voltage = 0;
            }
            // Test input is "1"
            else if (input1 == "1")
            {
                // Assign 18 to voltage
                voltage = 18;
            }
            // Test input is "2"
            else if (input1 == "2")
            {
                // Assign 24 to voltage
                voltage = 24;
            }
            // Otherwise
            else
            {
                // Write "Invalid option."
                // Return to calling (previous) method
                // return;
                Console.WriteLine("Invalid option.");
                return;

            }

            // Create found variable to hold list of found appliances.
            List<Appliance> found = new List<Appliance>();
            // Loop through Appliances
            foreach (Appliance appliance in Appliances)
            {
                // Check if current appliance is vacuum
                if (appliance is Vacuum)
                {
                    // Down cast current Appliance to Vacuum object
                    // Vacuum vacuum = (Vacuum)appliance;
                    Vacuum vacuum = (Vacuum)appliance;

                    // Test grade is "Any" or grade is equal to current vacuum grade and voltage is 0 or voltage is equal to current vacuum voltage
                    if ((grade == "Any" || grade == vacuum.Grade) && (voltage == 0 || voltage == vacuum.BatteryVoltage))
                    {
                        // Add current appliance in list to found list
                        found.Add(appliance);
                    }

                }
            }

            // Display found appliances
            // DisplayAppliancesFromList(found, 0);
            DisplayAppliancesFromList(found, 0);
        }



        /// <summary>
        /// Displays microwaves
        /// </summary>
        public override void DisplayMicrowaves()
        {
            Console.WriteLine("Possible options: ");

            // Write "0 - Any"
            Console.WriteLine("0 - Any");

            // Write "1 - Kitchen"
            Console.WriteLine("1 - Kitchen");

            // Write "2 - Work site"
            Console.WriteLine("2 - Work site");

            // Write "Enter room type:"
            Console.WriteLine("Enter room type: ");

            // Get user input as string and assign to variable
            string input = Console.ReadLine();

            // Create character variable that holds room type
            char roomtype;

            // Test input is "0"
            if (input == "0")
            {
                // Assign 'A' to room type variable
                roomtype = 'A';
            }
            // Test input is "1"
            else if (input == "1")
            {
                // Assign 'K' to room type variable
                roomtype = 'K';
            }
            // Test input is "2"
            else if (input == "2")
            {
                // Assign 'W' to room type variable
                roomtype = 'W';
            }

            // Otherwise (input is something else)
            else
            {
                // Write "Invalid option."
                // Return to calling method
                // return;
                Console.WriteLine("Invalid option.");
                return;
            }

            // Create variable that holds list of 'found' appliances
            List<Appliance> found = new List<Appliance>();

            // Loop through Appliances
            foreach (Appliance appliance in Appliances)
            {
                // Test current appliance is Microwave
                if (appliance is Microwave)
                {
                    // Down cast Appliance to Microwave
                    Microwave microwave = (Microwave)appliance;

                    // Test room type equals 'A' or microwave room type
                    // Add current appliance in list to found list
                    if (roomtype == 'A' || roomtype == microwave.RoomType)
                    {
                        found.Add(appliance);
                    }
                }

            }

            // Display found appliances
            // DisplayAppliancesFromList(found, 0);
            DisplayAppliancesFromList(found, 0);

        }


        /// <summary>
        /// Displays dishwashers
        /// </summary>
        public override void DisplayDishwashers()
        {
            // Write "Possible options:"

            // Write "0 - Any"
            // Write "1 - Quietest"
            // Write "2 - Quieter"
            // Write "3 - Quiet"
            // Write "4 - Moderate"

            Console.WriteLine("Possible options:");
            Console.WriteLine("0 - Any");
            Console.WriteLine("1 - Quietest");
            Console.WriteLine("2 - Quieter");
            Console.WriteLine("3 - Quiet");
            Console.WriteLine("4 - Moderate");


            // Write "Enter sound rating:"
            Console.WriteLine("Enter sound rating: ");

            // Get user input as string and assign to variable
            string input = Console.ReadLine();

            // Create variable that holds sound rating
            string soundrating = "";

            // Test input is "0"
            if (input == "0")
            {
                // Assign "Any" to sound rating variable
                soundrating = "Any";
            }

            // Test input is "1"
            else if (input == "1")
            {
                // Assign "Qt" to sound rating variable
                soundrating = "Qt";
            }

            // Test input is "2"
            else if (input == "2")
            {
                // Assign "Qr" to sound rating variable
                soundrating = "Qr";
            }

            // Test input is "3"
            else if (input == "3")
            {
                // Assign "Qu" to sound rating variable
                soundrating = "Qu";
            }

            // Test input is "4"
            else if (input == "4")
            {
                // Assign "M" to sound rating variable
                soundrating = "M";
            }

            // Otherwise (input is something else)
            else
            {
                // Write "Invalid option."
                // Return to calling method
                Console.WriteLine("Invalid option.");
                return;
            }


            // Create variable that holds list of found appliances
            List<Appliance> found = new List<Appliance>();
            // Loop through Appliances
            foreach (Appliance appliance in Appliances)
            {
                // Test if current appliance is dishwasher
                if (appliance is Dishwasher)
                {
                    // Down cast current Appliance to Dishwasher
                    Dishwasher dishwasher = (Dishwasher)appliance;

                    // Test sound rating is "Any" or equals soundrating for current dishwasher
                    if (soundrating == "Any" || soundrating == dishwasher.SoundRating)
                    {
                        // Add current appliance in list to found list
                        found.Add(appliance);
                    }
                }
            }


            // Display found appliances (up to max. number inputted)
            // DisplayAppliancesFromList(found, 0);
            DisplayAppliancesFromList(found, 0);
        }


        /// <summary>
        /// Generates random list of appliances
        /// </summary>
        public override void RandomList()
        {
            // Write "Appliance Types"

            // Write "0 - Any"
            // Write "1 – Refrigerators"
            // Write "2 – Vacuums"
            // Write "3 – Microwaves"
            // Write "4 – Dishwashers"
            // Write "Appliance Types"
            Console.WriteLine("Appliance Types");
            Console.WriteLine("0 - Any");
            Console.WriteLine("1 - Refrigerators");
            Console.WriteLine("2 - Vacuums");
            Console.WriteLine("3 - Microwaves");
            Console.WriteLine("4 - Dishwashers");

            // Write "Enter type of appliance:"
            Console.WriteLine("Enter type of appliance: ");

            // Get user input as string and assign to appliance type variable
            string input = Console.ReadLine();
            ////string applianceType = "";

            // Write "Enter number of appliances: "
            Console.WriteLine("Enter number of appliances: ");

            // Get user input as string and assign to variable
            string input1 = Console.ReadLine();

            // Convert user input from string to int
            int input3 = Convert.ToInt32(input1);


            // Create variable to hold list of found appliances
            List<Appliance> found = new List<Appliance>();

            // Loop through appliances
            foreach (Appliance appliance in Appliances)
            {
                // Test inputted appliance type is "0"
                if (input == "0")
                {
                    // Add current appliance in list to found list
                    found.Add(appliance);
                }

                // Test inputted appliance type is "1"
                else if (input == "1")
                {
                    // Test current appliance type is Refrigerator
                    if (appliance is Refrigerator)
                    {
                        // Add current appliance in list to found list
                        found.Add(appliance);
                    }

                }
                // Test inputted appliance type is "2"
                else if (input == "2")
                {
                    // Test current appliance type is Vacuum
                    if (appliance is Vacuum)
                    {
                        // Add current appliance in list to found list
                        found.Add(appliance);
                    }
                }

                // Test inputted appliance type is "3"
                else if (input == "3")
                {
                    // Test current appliance type is Microwave
                    if (appliance is Microwave)
                    {
                        // Add current appliance in list to found list
                        found.Add(appliance);
                    }
                }

                // Test inputted appliance type is "4"
                else if (input == "4")
                {
                    // Test current appliance type is Dishwasher
                    if (appliance is Dishwasher)
                    {
                        // Add current appliance in list to found list
                        found.Add(appliance);
                    }
                }
            }


            // Randomize list of found appliances

            // found.Sort(new RandomComparer());
            found.Sort(new RandomComparer());

            // Display found appliances (up to max. number inputted)
            // DisplayAppliancesFromList(found, num);
            DisplayAppliancesFromList(found, input3);
        }
    }
}



